import { CommonModule } from '@angular/common';
import { HttpClientModule } from '@angular/common/http';
import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { LanguageTranslationModule } from './shared/modules/language-translation/language-translation.module'

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { AuthGuard } from './shared';
import { DemosComponent } from './demos/demos.component';
import { Observable, of, Subject } from 'rxjs';

import { UploadComponent } from './upload/upload.component';
import { EventLogComponent } from './event-log/event-log.component';
import { ImgComponent } from './img/img.component';
import { FaqsComponent } from './faqs/faqs.component';
import { PracticeComponent } from './practice/practice.component';
import { NavbarComponent } from './navbar/navbar.component';

import { MaterialModule } from './material/material.module';
@NgModule({
    imports: [
        CommonModule,
        BrowserModule,
        BrowserAnimationsModule,
        HttpClientModule,
        LanguageTranslationModule,
        AppRoutingModule,
        MaterialModule
    ],
    declarations: [AppComponent,
        
        DemosComponent,
        EventLogComponent,
        UploadComponent,
        ImgComponent,
        FaqsComponent,
        PracticeComponent,
        NavbarComponent ],
        
       
    providers: [AuthGuard],
    bootstrap: [AppComponent]
})
export class AppModule {}
